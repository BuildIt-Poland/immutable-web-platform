* https://github.com/NixOS/nixos-org-configurations/tree/master/hydra-provisioner
* https://github.com/peti/hydra-tutorial
